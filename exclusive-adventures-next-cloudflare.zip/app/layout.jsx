import './globals.css'
import Script from 'next/script'

export const metadata = {
  title: 'Exclusive Adventures Colombia | Luxury Travel in Cartagena, Medellín & Cali',
  description: "Discover Colombia through bespoke experiences — private yachts, helicopter tours, and cultural escapes designed for the discerning traveler.",
  openGraph: {
    title: 'Exclusive Adventures Colombia | Luxury Travel',
    description: 'Private, bespoke travel experiences designed for those who\'ve done it all.',
    images: '/og-colombia.jpg'
  }
}

export default function RootLayout({ children }){
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet" />
      </head>
      <body>
        {/* GA4 placeholder - set NEXT_PUBLIC_GA_ID in Cloudflare Pages */}
        <Script src={"https://www.googletagmanager.com/gtag/js?id=" + (process.env.NEXT_PUBLIC_GA_ID || 'G-XXXXXXXXXX')} strategy="afterInteractive" />
        <Script id="ga-setup" strategy="afterInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config','${process.env.NEXT_PUBLIC_GA_ID || 'G-XXXXXXXXXX'}');`}</Script>
        {children}
      </body>
    </html>
  )
}
