export async function POST(request) {
  try {
    const body = await request.json()
    // TODO: validate and forward to Mailchimp or Google Sheets via a secure Cloudflare Worker or server
    return new Response(JSON.stringify({ ok: true }), { status: 200 })
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 })
  }
}
