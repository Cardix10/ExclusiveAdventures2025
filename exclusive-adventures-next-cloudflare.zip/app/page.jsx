'use client'
import Hero from '../components/Hero'
import Featured from '../components/Featured'
import About from '../components/About'
import Membership from '../components/Membership'

export default function Page(){
  return (
    <main className="bg-black text-white min-h-screen">
      <Hero />
      <Featured />
      <About />
      <Membership />
      <footer className="py-8 text-center opacity-70">© {new Date().getFullYear()} Exclusive Adventures</footer>
    </main>
  )
}
