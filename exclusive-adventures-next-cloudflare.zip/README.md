# Exclusive Adventures — Next.js + Cloudflare Pages (Cursor-ready)

This repo is pre-configured for GitHub + Cloudflare Pages with the cinematic Colombia visuals (placeholders). Replace environment placeholders in Cloudflare Pages or GitHub Secrets before going live.

## Placeholders to set in Cloudflare Pages (Environment variables)
- NEXT_PUBLIC_GA_ID = G-XXXXXXXXXX
- MAILCHIMP_API_KEY = your-mailchimp-api-key (for server-side calls in a Worker)
- MAILCHIMP_LIST_ID = your-mailchimp-list-id
- CLOUDFLARE_PAGES_PROJECT = your-pages-project-name

## Local dev
1. Install dependencies
   ```bash
   npm ci
   ```
2. Start dev server
   ```bash
   npm run dev
   ```

## Deploy (Cloudflare Pages via GitHub Actions)
1. Push repo to GitHub `main` branch.
2. Add repo secrets: `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_PAGES_PROJECT`.
3. Merge to `main` — workflow will build & deploy.

## Media
Add compressed hero video and images to `/public` as listed in `/public/README.md`.

## Notes
- Replace `/app/api/subscribe/route.js` with a Cloudflare Worker that forwards to Mailchimp or Google Sheets with server-side secrets.
- Keep API keys out of the client. Use server-side forwarding in Workers or Edge functions.
