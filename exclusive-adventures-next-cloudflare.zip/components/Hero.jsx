'use client'
import React from 'react'

export default function Hero(){
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <video className="absolute inset-0 w-full h-full object-cover" autoPlay muted loop playsInline poster="/hero-poster.jpg">
        <source src="/hero-cartagena.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-gradient-to-b from-[rgba(0,0,0,0.35)] via-[rgba(0,0,0,0.55)] to-[rgba(15,7,0,0.9)]" aria-hidden></div>

      <div className="relative z-10 max-w-5xl text-center px-6">
        <h1 className="playfair text-5xl md:text-6xl lg:text-7xl font-extrabold">Experience Colombia’s Most Exclusive Adventures</h1>
        <p className="mt-6 text-lg md:text-xl max-w-2xl mx-auto">From Cartagena’s coastlines to Medellín’s mountains and Cali’s rhythm — bespoke journeys curated for the discerning traveler.</p>

        <div className="mt-8 flex justify-center gap-4">
          <a href="#featured" className="cta-primary">Join the Journey</a>
          <button className="cta-outline" onClick={()=>document.getElementById('invite-form')?.scrollIntoView({behavior:'smooth'})}>Request an Invitation</button>
        </div>
      </div>
    </section>
  )
}
