'use client'
import { motion } from 'framer-motion'

const items = [
  { title: "Private Yacht Charter in Cartagena's Rosario Islands", img: '/rosario.jpg' },
  { title: "Helicopter Tour over Medellín's Aburrá Valley", img: '/medellin.jpg' },
  { title: 'Luxury Salsa Weekend & Fine Dining in Cali', img: '/cali.jpg' }
]

export default function Featured(){
  return (
    <section id="featured" className="py-20">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="playfair text-4xl mb-8">Featured Experiences</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((it, idx) => (
            <motion.article key={idx} whileHover={{ scale: 1.03 }} className="overflow-hidden rounded-2xl bg-gray-900 shadow-xl">
              <img src={it.img} alt={it.title} loading="lazy" className="w-full h-64 object-cover" />
              <div className="p-6">
                <h3 className="font-semibold text-xl">{it.title}</h3>
                <p className="mt-2 text-sm opacity-80">Bespoke itinerary, private guides, and exclusive access.</p>
                <div className="mt-4"><button className="card-cta">View Experience</button></div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
