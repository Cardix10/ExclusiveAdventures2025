export default function About(){
  return (
    <section id="about" className="py-20 bg-black/60">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="playfair text-3xl">About Exclusive Adventures</h2>
        <p className="mt-6">Exclusive Adventures curates elite travel experiences across Colombia’s most captivating cities — blending adventure, comfort, and culture in perfect harmony.</p>
      </div>
    </section>
  )
}
