'use client'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'

const schema = yup.object({
  fullName: yup.string().required('Full name is required'),
  email: yup.string().email('Enter a valid email').required('Email is required'),
  message: yup.string().optional()
})

export default function Membership(){
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const { register, handleSubmit, formState:{errors}, reset } = useForm({ resolver: yupResolver(schema) })

  async function onSubmit(data){
    setLoading(true)
    try{
      # Placeholder: replace with your Cloudflare Worker endpoint or server
      await fetch('/api/subscribe', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) })
      if(window.gtag) window.gtag('event','newsletter_signup',{method:'membership_form'})
      reset()
      setSubmitted(true)
    }catch(e){
      console.error(e)
      alert('Submission failed. Please try again later.')
    }finally{ setLoading(false) }
  }

  return (
    <section className="py-20">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="playfair text-3xl">Membership</h2>
        <p className="mt-4">Choose your access: Explorer (free) or Elite (by invitation).</p>

        <div className="mt-8 grid md:grid-cols-2 gap-8">
          <div className="p-8 rounded-2xl bg-gray-900/40">
            <h3 className="text-xl font-semibold">Explorer</h3>
            <p className="mt-2">Free — email access only</p>
            <div className="mt-4"><button className="card-cta">Join Explorer</button></div>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-br from-[#0b0b0b] to-[#0b0500]/20">
            <h3 className="text-xl font-semibold">Elite</h3>
            <p className="mt-2">Premium — concierge, early access</p>

            <form id="invite-form" onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
              <div>
                <input {...register('fullName')} placeholder="Full Name" className="form-input" aria-invalid={errors.fullName ? 'true' : 'false'} />
                {errors.fullName && <div className="text-red-400 text-sm">{errors.fullName.message}</div>}
              </div>
              <div>
                <input {...register('email')} placeholder="Email Address" className="form-input" aria-invalid={errors.email ? 'true' : 'false'} />
                {errors.email && <div className="text-red-400 text-sm">{errors.email.message}</div>}
              </div>
              <div>
                <textarea {...register('message')} placeholder="Tell us about your ideal adventure (optional)" className="form-textarea"></textarea>
              </div>

              <div className="flex items-center gap-4">
                <button type="submit" className="btn-submit" disabled={loading}>{loading ? 'Sending…' : 'Request an Invitation'}</button>
              </div>

              {submitted && <div className="mt-4 text-sm bg-white/5 p-3 rounded">Your request has been received. Our concierge team will contact you soon.</div>}
            </form>

          </div>
        </div>
      </div>
    </section>
  )
}
