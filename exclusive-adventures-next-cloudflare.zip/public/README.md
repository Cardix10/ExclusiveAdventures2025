Place your media files here (compressed for web):
- hero-cartagena.mp4        (compressed hero video)
- hero-poster.jpg
- rosario.jpg
- medellin.jpg
- cali.jpg
- og-colombia.jpg
- favicon.ico
- apple-touch-icon.png
